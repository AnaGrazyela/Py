for i in range(1,10001):
    if i % 10 == 0:
        print(i)