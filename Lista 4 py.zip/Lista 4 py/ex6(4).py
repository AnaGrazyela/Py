n = int(input("Digite quantos números você vai querer: "))

soma = 0

for i in range(n):
    num = int(input(f"Digite {i+1}° número: "))
    soma += num
media = soma / n
print(f"A media é: {media:.2f}")