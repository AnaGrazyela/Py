num1 = int(input("Digite seu número: "))
num2 = int(input("Digite seu segundo número: "))

inicio = min(num1,num2) + 1
fim = max(num1,num2)
soma = 0
for i in range (inicio,fim):
    soma += i

print(f"A soma dos números entre {num1} e {num2} é: {soma}") 