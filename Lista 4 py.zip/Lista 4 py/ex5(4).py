soma = 0 
impar = 1

for i in range(200):
    soma += impar
    impar += 2    #aqui, ele irá pular para a próximo nmr impar

print(f"O 200 números impar são: {soma}")
