for tabuada in range(1,11):
    print(f"Tabuada {tabuada}")
    for i in range(1,11):
        print(f"{tabuada} x {i} = {tabuada * i}")