print ("Contando de 1 até 100: ")
for i in range(1,101):  #o laço "for" quando a repetição é com quantidade definida 
    print(i)

print ("Contando de 100 até 1: ")
for i in range(100,0,-1):
    print(i)