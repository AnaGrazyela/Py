nota = float(input("Digite a sua nota: "))

if 9 <= nota <= 10:
    print("Conceito A")
elif nota >= 8:
    print("Conceito B")
elif nota >= 7:
    print("Conceito C")
else:
    print("Conceito D")
