num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))

if num1 < num2:
    print(f"O número maior é: {num2}")
else:
    print(f"o número maior é:{num1}")