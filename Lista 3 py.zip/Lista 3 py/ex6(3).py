num = int(input("Digite um número: "))

if num % 6 == 0:
    print("Este número é divisível")
else:
    print("Este número não é divisível")